use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;

nexto da I.

primo tertii noni septimi unimatrixorum nexto postincrescementum da.
nextum tum novumversum egresso scribe.
primum tertii noni septimi unimatrixorum prevo da.
prevum tum novumversum egresso scribe.
primo tertiae nonae septimae unimatrixorum nexto preincrescementum da.
nextum tum novumversum egresso scribe.
primam tertii noni septimi unimatrixorum prevo da.
prevum tum novumversum egresso scribe.

scribe egresso unam quartam tum lacunam tum tres quartas tum novumversum.

