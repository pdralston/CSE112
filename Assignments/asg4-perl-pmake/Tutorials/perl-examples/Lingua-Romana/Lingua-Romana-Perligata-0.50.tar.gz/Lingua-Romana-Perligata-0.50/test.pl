print "1..10\n";

use Lingua::Romana::Perligata;

per nextum in unam tum X conscribementis fac sic
       nextum oute.
cis

outere sic
    scribe egresso ok tum lacunam tum nullimum horum tum novumversum.
cis
